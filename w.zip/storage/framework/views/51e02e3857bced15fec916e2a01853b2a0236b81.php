

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="card p-4">
            <div class="row">
                <div class="col">
                    <div class="row">
                        <div class="col-md-1">
                            <h4 class="bg-info text-white rounded-circle px-2" style="width: fit-content">
                                1
                            </h4>
                        </div>
                        <div class="col-md-6">
                            Text
                        </div>
                    </div>
                    <img width="200" src="<?php echo e(asset('storage/img/left-image.png')); ?>" alt="">
                </div>
                <div class="col">
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webgis-Rumah-Sakit\resources\views/panduan.blade.php ENDPATH**/ ?>