<?php use App\Http\Controllers\HomeController;
?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div>
            <a href="<?php echo e(route('home')); ?>" class="text-decoration-none text-dark py-1 btn btn-outline-info me-2">
                <i class="fa-solid fa-arrow-left"></i>
            </a>
        </div>
        <div class="row">
            <?php $__currentLoopData = $data->dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($item->jadwal)): ?>
                    <div class="col-md-4">
                        <!-- small box -->
                        <div class="card p-2 text-white" style="background-color:<?php echo e($colors[$loop->index % 2 == 0]); ?>">
                            <h5><?php echo e($item->nama_dokter); ?></h5>
                            <?php $__currentLoopData = $item->jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-2">
                                    <p class="mb-0 text-white"> Spesialis <?php echo e($item->spesialis2); ?></p>
                                    <p class="mb-0 text-white">Jadwal : <?php echo e($jadwal->jadwal->isoFormat('dddd')); ?>

                                        <?php echo e($jadwal->jadwal->isoFormat('LL')); ?>


                                    </p>
                                    <p class="mb-0 text-white">
                                        Pukul <?php echo e($jadwal->jadwal->isoFormat('H:MM a')); ?>

                                    </p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webgis-Rumah-Sakit\resources\views/rs-jadwal.blade.php ENDPATH**/ ?>