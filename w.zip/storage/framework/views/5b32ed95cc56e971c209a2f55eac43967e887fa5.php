

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card p-4">
            <form action="<?php echo e(route('update jadwal',['id'=>$id])); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hari</label>
                            <select name="hari" class="form-control">
                                <option value="">--pilih hari--</option>
                                <option <?php echo e($data->hari == 'Senin'? 'selected':''); ?> value="Senin">Senin</option>
                                <option <?php echo e($data->hari == 'Selasa'? 'selected':''); ?> value="Selasa">Selasa</option>
                                <option <?php echo e($data->hari == 'Rabu'? 'selected':''); ?> value="Rabu">Rabu</option>
                                <option <?php echo e($data->hari == 'Kamis'? 'selected':''); ?> value="Kamis">Kamis</option>
                                <option <?php echo e($data->hari == 'Jumat'? 'selected':''); ?> value="Jumat">Jumat</option>
                                <option <?php echo e($data->hari == 'Sabtu'? 'selected':''); ?> value="Sabtu">Sabtu</option>
                                <option <?php echo e($data->hari == 'Minggu'? 'selected':''); ?> value="Minggu">Minggu</option>
                            </select>
                        </div>
                         <div class="form-group">
                            <label>Jam</label>
                             <input name="jam" type="time" class="form-control" value="<?php echo e($data->jam); ?>" required>
                        </div>
                    </div>
                </div>  

                <button class="btn btn-primary float-end mt-4" type="submit">Tambah</button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webgis-Rumah-Sakit\resources\views/edit-jadwal.blade.php ENDPATH**/ ?>