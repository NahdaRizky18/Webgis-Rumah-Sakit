

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card p-4">
            <form action="<?php echo e(route('store jadwal')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Dokter</label>
                            <select name="halaman_data2_id" class="form-control">
                                <option value="">--pilih dokter--</option>
                                <?php $__currentLoopData = $dokters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_dokter); ?> (<?php echo e($item->spesialis2); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                       
                        <div class="form-group">
                            <label>Jadwal</label>
                            <input name="jadwal" type="datetime-local" class="form-control" required>
                            <input name="user_id" type="hidden" value="<?php echo e(auth()->user()->id); ?>" class="form-control"
                                required>
                        </div>
                    </div>
                </div>

                <button class="btn btn-primary float-end mt-4" type="submit">Tambah</button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webgis-Rumah-Sakit\resources\views/tambah-jadwal.blade.php ENDPATH**/ ?>