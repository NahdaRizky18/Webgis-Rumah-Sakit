

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('storage/css/halaman-data.css')); ?>">


    <div class="container-xl">
        <div class="table-responsive">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-6">
                            <h2>Data <b>Ruangan Rumah Sakit</b></h2>
                        </div>
                        <div class="col-sm-6">
                            <a href="<?php echo e(route('tambah ruangan')); ?>" class="btn btn-success"><i
                                    class="material-icons">&#xE147;</i> <span>Masukkan Data Baru</span></a>
                        </div>
                    </div>
                </div>
                <table class="table table-striped table-hover" id="table">
                    <thead>
                        <tr>
                            <th>
                                No
                            </th>
                            <th>Name</th>
                            <th>Kelas</th>
                            <th>Kapasitas</th>
                            <th>Tersedia</th>
                            <th>Tersedia Laki-laki</th>
                            <th>Tersedia Perempuan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->kelas); ?></td>
                                <td><?php echo e($item->kapasitas); ?></td>
                                <td><?php echo e($item->tersedia); ?></td>
                                <td><?php echo e($item->tersedia_lk); ?></td>
                                <td><?php echo e($item->tersedia_pr); ?></td>
                                <td class="w-25">
                                    <form action="<?php echo e(route('delete ruangan', ['id' => $item->id])); ?>" method="get">
                                        <a href="<?php echo e(route('edit ruangan', ['id' => $item->id])); ?>"
                                            class="edit"><i class="material-icons" data-toggle="tooltip"
                                                title="Edit">&#xE254;</i></a>
                                        <button type="submit" class="delete show_confirm border-0 p-0 bg-transparent"><i
                                                class="material-icons" data-toggle="tooltip"
                                                title="Delete">&#xE872;</i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Edit Modal HTML -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $('.show_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Anda yakin ingin menghapus data ini`,
                    text: "Data akan hilang secara permanen",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
        $(document).ready(function() {
            $('#table').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webgis-Rumah-Sakit\resources\views/ruangan.blade.php ENDPATH**/ ?>