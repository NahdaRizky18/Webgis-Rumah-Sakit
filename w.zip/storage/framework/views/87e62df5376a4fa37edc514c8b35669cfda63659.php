

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card p-4">
            <form action="<?php echo e(route('update data2', ['id' => $id])); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                      
                        <div class="form-group">
                            <label>Nama Dokter</label>
                            <input name="nama_dokter" type="text" class="form-control" required
                                value="<?php echo e($data->nama_dokter); ?>">
                        </div>
                        <div class="form-group">
                            <label>Spesialis</label>
                            <input name="spesialis2" type="text" class="form-control" required value="<?php echo e($data->spesialis2); ?>">
                            
                        </div>
                        <div class="form-group">
                            <label>poliklinik</label>
                            <input name="poli" type="text" class="form-control" required value="<?php echo e($data->poli); ?>">
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary float-end mt-4" type="submit">Simpan</button>
            </form>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webgis-Rumah-Sakit\resources\views/edit2.blade.php ENDPATH**/ ?>